$(function(){
	$('.nav').children('div').eq(0).click(function(){
		window.location.href = "ONE.html"
	})
	$('.nav').children('div').eq(1).click(function(){
		window.location.href = "about_us.html"
	})
	$('.nav').children('div').eq(2).click(function(){
		window.location.href = "cooperation.html"
	})
	$('.nav').children('div').eq(3).click(function(){
		window.location.href = "join_us.html"
	})
})